﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace SuperScrollView
{
    public class ListItem16 : MonoBehaviour
    {
        public Text mNameText;
        
        public void Init()
        {
            
        }
    }
}
