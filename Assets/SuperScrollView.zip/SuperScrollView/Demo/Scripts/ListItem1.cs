﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace SuperScrollView
{
    public class ListItem1 : MonoBehaviour
    {
        public Image mItemIcon;
        public Text mBtnText;
        public Button mBtn;
        public int mSpriteStartIndex;
    }
}
